#include "PluginProcessor.h"
#include "PluginEditor.h"

namespace {
    constexpr double kSixteenthQ = 0.25;      // 1/16th in quarter-notes
    constexpr double kBarEps     = 1.0e-6;    // bar-start epsilon

    // Fast rounding for known non-negative values (avoids std::llround overhead)
    inline int fastRoundPositive(double x) { return (int) (x + 0.5); }

    inline void addBoth(juce::MidiBuffer& mainBuf, juce::MidiBuffer& extBuf, const juce::MidiMessage& msg, int sample)
    {
        mainBuf.addEvent(msg, sample);
        extBuf.addEvent(msg, sample);
    }
}

//==============================================================================
ClockSyncAudioProcessor::ClockSyncAudioProcessor()
    : juce::AudioProcessor(
#if JucePlugin_IsMidiEffect
          BusesProperties() // MIDI effect: no audio buses
#elif JucePlugin_IsSynth
          // Synth/instrument: only output bus
          BusesProperties().withOutput("Output", juce::AudioChannelSet::stereo(), true)
#else
          // Effect plugin (FX): provide both input and output buses
          BusesProperties()
              .withInput("Input", juce::AudioChannelSet::stereo(), true)
              .withOutput("Output", juce::AudioChannelSet::stereo(), true)
#endif
      ),
      parameters(*this, nullptr, juce::Identifier("ClockSyncParams"), createParameterLayout())
{
}

void ClockSyncAudioProcessor::requestTriggerOnce()
{
    // Original behaviour (clock_org): Arm Start at next 1/16 grid boundary (immediate retrigger).
    // Whether a bar+offset restart follows is decided later based on triggerModeEnabled.
    triggerArmedForNextSixteenth.store(true, std::memory_order_relaxed);
    // diagnostics logging removed per user request
}

void ClockSyncAudioProcessor::setTriggerModeEnabled(bool enabled)
{
    triggerModeEnabled.store(enabled, std::memory_order_relaxed);
}

void ClockSyncAudioProcessor::notifyResyncOffsetChanged()
{
    pendingBarRestart.store(true, std::memory_order_relaxed);
    uiNextRestartPending.store(true, std::memory_order_relaxed);
}

//==============================================================================
juce::AudioProcessorValueTreeState::ParameterLayout ClockSyncAudioProcessor::createParameterLayout()
{
    std::vector<std::unique_ptr<juce::RangedAudioParameter>> params;

    params.push_back(std::make_unique<juce::AudioParameterChoice>(
        paramClockRateIndex, "Clock Rate", juce::StringArray{ "1/32", "1/16", "1/8", "1/4" }, 1));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        paramClickLevelDb, "Click Level (dB)", juce::NormalisableRange<float>(-12.0f, 0.0f), -6.0f));

    // Click rate: discrete stages 0..4 (0 = off). Default changed to 0 so rotary starts at OFF.
    params.push_back(std::make_unique<juce::AudioParameterInt>(
        paramClickRate, "Click Rate", 0, 4, 0));

    // Click variant: false = 1-sample spike, true = 1ms pulse
    params.push_back(std::make_unique<juce::AudioParameterBool>(
        paramClickPulse, "Click Pulse Variant", false));

    params.push_back(std::make_unique<juce::AudioParameterBool>(
        paramRun, "Run", true));
    params.push_back(std::make_unique<juce::AudioParameterBool>(
        paramClockWhileStopped, "Clock While Stopped", false));

    // Trigger mode: when enabled, a manual trigger also schedules a bar/offset restart
    params.push_back(std::make_unique<juce::AudioParameterBool>(
        paramTriggerModeEnabled, "Trigger Mode", true));

    // Step offset within the bar where restarts occur (1..16). 1 means at bar start; 5 means 4/16 into next bar.
    params.push_back(std::make_unique<juce::AudioParameterInt>(
        paramResyncOffsetStep, "Resync Offset Step", 1, 16, 1));

    // Shuffle (swing) intensity: 1..7 (TR-909 style). 1 = none, 7 = maximum (2nd 16th shifted to next 32nd).
    params.push_back(std::make_unique<juce::AudioParameterInt>(
        paramShuffleStep, "Shuffle Step", 1, 7, 1));

    // Optional diagnostics (off by default). When enabled, logs a few swing timing lines to ~/Documents/ClockSync_Log.txt
    params.push_back(std::make_unique<juce::AudioParameterBool>(
        paramDiagnostics, "Diagnostics", false));

    // Pattern bars choice: OFF,1,2,4,8,16,32,64,RND (store as indices 0..8)
    params.push_back(std::make_unique<juce::AudioParameterChoice>(
        paramPatternBars, "Pattern Bars", juce::StringArray{ "OFF","1","2","4","8","16","32","64","RND" }, 0));
    // Pattern steps bitmask (0..65535) persisted; editor updates via setPatternSteps
    params.push_back(std::make_unique<juce::AudioParameterInt>(
        paramPatternSteps, "Pattern Steps Mask", 0, 65535, 0));

    return { params.begin(), params.end() };
}

//==============================================================================
void ClockSyncAudioProcessor::prepareToPlay(double sr, int /*samplesPerBlock*/)
{
    currentSampleRate = sr > 0.0 ? sr : 44100.0;
    lastWasPlaying = false;
    lastTickIndex = std::numeric_limits<long long>::min();
    pendingRateIndex = -1;
    currentRateIndex = 1; // 1/16 => normal speed (24)
    // Default: armed but not running; will emit Start at scheduled offset step (or bar start)
    pendingStart = true;
    runActive = false;
    // No forced wrap to next bar in original behaviour
    forceNextBarStart = false;
    // removed unused lastRunParam
    clickEnv = 0.0f;
    uiClockCounter.store(0, std::memory_order_relaxed);
    uiIsRunning.store(false, std::memory_order_relaxed);
    uiPendingStart.store(true, std::memory_order_relaxed);
    uiNextRestartPending.store(false, std::memory_order_relaxed);
    triggerArmedForNextSixteenth.store(false, std::memory_order_relaxed);
    pendingBarRestart.store(false, std::memory_order_relaxed);
    // Initial trigger mode from parameter
    if (auto* tv = parameters.getRawParameterValue(paramTriggerModeEnabled))
    {
        const bool tm = tv->load() > 0.5f;
        triggerModeEnabled.store(tm, std::memory_order_relaxed);
        lastTriggerModeEnabled = tm;
    }
    else
    {
        triggerModeEnabled.store(true, std::memory_order_relaxed);
        lastTriggerModeEnabled = true;
    }
    suppressUntilRestart = false;
    firstBlock = true;
    if (auto* pi = dynamic_cast<juce::AudioParameterInt*>(parameters.getParameter(paramResyncOffsetStep)))
        lastOffsetStep = juce::jlimit(1, 16, pi->get());
    if (auto* si = dynamic_cast<juce::AudioParameterInt*>(parameters.getParameter(paramShuffleStep)))
        currentShuffleStep = juce::jlimit(1, 7, si->get());
    pendingShuffleStep = -1;
    applyShuffleAtPPQ = -1.0;
    diagnosticsEnabled = false;
    diagPairsRemaining = 0;
    diagLastLoggedPair = std::numeric_limits<long long>::min();
    diagLastSample = -1;
    updateDerivedParams();
    updateExternalOut();
    // Reset persistent accumulators on prepare (sample-rate change / reinitialise)
    resetAccumulators();
}

void ClockSyncAudioProcessor::releaseResources() {}

bool ClockSyncAudioProcessor::isBusesLayoutSupported(const BusesLayout& layouts) const
{
#if JucePlugin_IsMidiEffect
    // MIDI effect: no audio buses
    return layouts.getMainInputChannelSet() == juce::AudioChannelSet::disabled()
        && layouts.getMainOutputChannelSet() == juce::AudioChannelSet::disabled();
#elif JucePlugin_IsSynth
    // Synth/instrument: no audio input; allow mono or stereo output
    if (layouts.getMainInputChannelSet() != juce::AudioChannelSet::disabled())
        return false;

    const auto out = layouts.getMainOutputChannelSet();
    if (out != juce::AudioChannelSet::mono() && out != juce::AudioChannelSet::stereo())
        return false;

    return true;
#else
    // Effect: require matching input/output channel layouts (mono or stereo)
    const auto in = layouts.getMainInputChannelSet();
    const auto out = layouts.getMainOutputChannelSet();

    if (in == juce::AudioChannelSet::disabled() || out == juce::AudioChannelSet::disabled())
        return false;

    if (in != out)
        return false;

    if (in != juce::AudioChannelSet::mono() && in != juce::AudioChannelSet::stereo())
        return false;

    return true;
#endif
}

int ClockSyncAudioProcessor::getClockResolution() const
{
    // Map current rate index (choice param) to pulses-per-quarter note.
    // Index mapping (clockRateIndex):
    // 0 => 1/32 (double speed)  => 48 PPQN
    // 1 => 1/16 (normal speed)  => 24 PPQN
    // 2 => 1/8  (half speed)    => 12 PPQN
    // 3 => 1/4  (quarter speed) => 6 PPQN
    switch (currentRateIndex)
    {
        case 0: return 48;
        case 1: return 24;
        case 2: return 12;
        case 3: return 6;
        default: return 24;
    }
}

// void ClockSyncAudioProcessor::debugLog(const juce::String& s)
// {
//     juce::File f = juce::File::getSpecialLocation(juce::File::userDocumentsDirectory)
//                         .getChildFile("ClockSync_Log.txt");
//     if (auto stream = f.createOutputStream(1024))
//     {
//         stream->setPosition(stream->getFile().getSize());
//         stream->writeText(s + "\n", false, false, "UTF-8");
//     }
// }

void ClockSyncAudioProcessor::updateDerivedParams()
{
    const auto levelDb = parameters.getRawParameterValue(paramClickLevelDb)->load();
    if (! std::isfinite(lastClickLevelDbCached) || levelDb != lastClickLevelDbCached)
    {
        clickGainLinear = juce::Decibels::decibelsToGain(levelDb);
        lastClickLevelDbCached = levelDb;
    }
    // Mirror trigger mode parameter into fast atomic for RT checks
    if (auto* tv = parameters.getRawParameterValue(paramTriggerModeEnabled))
        triggerModeEnabled.store(tv->load() > 0.5f, std::memory_order_relaxed);

    updatePatternParams();
}

void ClockSyncAudioProcessor::resetAccumulators()
{
    fracAccPrimaryBefore = 0.0;
    fracAccPrimaryAfter = 0.0;
    lastBpmForAcc = -1.0;
}

void ClockSyncAudioProcessor::updateExternalOut()
{
    // Tear down existing
    if (externalMidiOut)
    {
        externalMidiOut->stopBackgroundThread();
        externalMidiOut.reset();
    }

    // Always use selected device if set
    if (externalDeviceId.isNotEmpty())
    {
        externalMidiOut = juce::MidiOutput::openDevice(externalDeviceId);
        if (externalMidiOut)
            externalMidiOut->startBackgroundThread();
    }
}

void ClockSyncAudioProcessor::setExternalDeviceId(const juce::String& id)
{
    if (externalDeviceId == id)
        return;

    externalDeviceId = id;
    // Persist into the state tree for recall
    parameters.state.setProperty("externalDeviceId", externalDeviceId, nullptr);
    // Reopen according to new device selection
    updateExternalOut();
}

//==============================================================================
void ClockSyncAudioProcessor::processBlock(juce::AudioBuffer<float>& buffer, juce::MidiBuffer& midi)
{
    juce::ScopedNoDenormals noDenormals;
    const int numSamples = buffer.getNumSamples();
    // Preserve incoming audio (passthrough). Only clear channels that have
    // no corresponding input (e.g. mismatched layouts) — current layout policy requires match.
    const int numIn  = getTotalNumInputChannels();
    const int numOut = getTotalNumOutputChannels();
    // If host gives mono in -> stereo out (future-proof), duplicate channel 0.
    if (numIn == 1 && numOut > 1)
    {
        for (int ch = 1; ch < numOut; ++ch)
            buffer.copyFrom(ch, 0, buffer, 0, 0, numSamples);
    }
    // If there are extra output channels beyond inputs, clear them to silence.
    for (int ch = numIn; ch < numOut; ++ch)
        buffer.clear(ch, 0, numSamples);

    juce::AudioPlayHead::CurrentPositionInfo pos;
    bool hasPos = false;
    if (auto* ph = getPlayHead())
    {
        if (auto opt = ph->getPosition())
        {
            hasPos = true;
            pos.resetToDefault();

            if (auto sig = opt->getTimeSignature())
            {
                pos.timeSigNumerator   = sig->numerator;
                pos.timeSigDenominator = sig->denominator;
            }

            if (auto loop = opt->getLoopPoints())
            {
                pos.ppqLoopStart = loop->ppqStart;
                pos.ppqLoopEnd   = loop->ppqEnd;
            }

            if (auto frame = opt->getFrameRate())
                pos.frameRate = *frame;

            if (auto timeInSeconds = opt->getTimeInSeconds())
                pos.timeInSeconds = *timeInSeconds;

            if (auto lastBarStartPpq = opt->getPpqPositionOfLastBarStart())
                pos.ppqPositionOfLastBarStart = *lastBarStartPpq;

            if (auto ppqPosition = opt->getPpqPosition())
                pos.ppqPosition = *ppqPosition;

            if (auto originTime = opt->getEditOriginTime())
                pos.editOriginTime = *originTime;

            if (auto bpm = opt->getBpm())
                pos.bpm = *bpm;

            if (auto timeInSamples = opt->getTimeInSamples())
                pos.timeInSamples = (juce::int64) *timeInSamples;

            pos.isPlaying   = opt->getIsPlaying();
            pos.isRecording = opt->getIsRecording();
            pos.isLooping   = opt->getIsLooping();
        }
    }

    if (! hasPos)
    {
        // No transport info; nothing to schedule for audio clicks.
        clickEnv = 0.0f;
        return;
    }

    generateClockAndClick(pos, buffer, midi);
}

void ClockSyncAudioProcessor::generateClockAndClick(const juce::AudioPlayHead::CurrentPositionInfo& pos,
                                                    juce::AudioBuffer<float>& buffer,
                                                    juce::MidiBuffer& midi)
{
    const int numSamples = buffer.getNumSamples();
    // Clear per-block pattern/bar-start markers
    lastPatternStartSampleInBlock = -1;
    lastBarRestartStartSampleInBlock = -1;
    // Update derived params (fast, read atomics)
    updateDerivedParams();

    // Centralized external MIDI buffer: collect all external messages here and send once at function end.
    juce::MidiBuffer extClock;

    // --- Cache parameter reads to avoid repeated dynamic_casts and lookups in inner loops ---
    auto* clickRateParam = dynamic_cast<juce::AudioParameterInt*>(parameters.getParameter(paramClickRate));
    const int clickRateCached = clickRateParam ? juce::jlimit(0, 4, clickRateParam->get()) : 0;
    const bool clickEnabled = (clickRateCached > 0);
    const bool clickPulseCached = parameters.getRawParameterValue(paramClickPulse)->load() > 0.5f;
    const bool diagnosticsParam = parameters.getRawParameterValue(paramDiagnostics)->load() > 0.5f;

    auto* choiceParam = dynamic_cast<juce::AudioParameterChoice*>(parameters.getParameter(paramClockRateIndex));
    if (choiceParam)
    {
        const int desired = choiceParam->getIndex();
        if (desired != currentRateIndex && pendingRateIndex != desired)
        {
            pendingRateIndex = desired;
            uiNextRestartPending.store(true, std::memory_order_relaxed);
        }
    }

    // Capture the resolution (locked to 24 for MIDI clock)
    const int resolutionBefore = getClockResolution();

    // Run control param
    const bool runParamCached = parameters.getRawParameterValue(paramRun)->load() > 0.5f;
    const bool keepClockStoppedCached = parameters.getRawParameterValue(paramClockWhileStopped)->load() > 0.5f;
    bool allowMidiOut = runParamCached || keepClockStoppedCached;

    

    // Detect run-param transitions (true -> false) so we can emit an immediate
    // MIDI Stop to external devices when user turns Run off. This makes the
    // UI Run toggle reliably stop external drum machines even if host
    // transport/clock settings would otherwise keep running.
    if (lastRunParam != runParamCached)
    {
        if (! runParamCached)
        {
            // Send an immediate Stop message at the start of this block.
            const auto stopMsg = juce::MidiMessage::midiStop();
            midi.addEvent(stopMsg, 0);
            // Queue Stop for external output; will be flushed once at end of this function.
            extClock.addEvent(stopMsg, 0);
            // Clear running state
            runActive = false;
            pendingStart = false;
            uiIsRunning.store(false, std::memory_order_relaxed);
            uiPendingStart.store(false, std::memory_order_relaxed);
        }
        // Keep original behaviour on Run==true: arm a pendingStart handled later in the main logic.
        lastRunParam = runParamCached;
    }

    const double bpm = (pos.bpm > 0.0 ? pos.bpm : 120.0);
    // If BPM changed since last block, conservatively reset accumulators to avoid stale carry.
    if (lastBpmForAcc < 0.0)
        lastBpmForAcc = bpm;
    else if (std::fabs(bpm - lastBpmForAcc) > 1e-6)
    {
        resetAccumulators();
        lastBpmForAcc = bpm;
    }
    uiBpm.store(bpm, std::memory_order_relaxed);
    samplesPerQuarter = currentSampleRate * 60.0 / juce::jmax(1e-6, bpm);

    const double ppqStart = pos.ppqPosition;
    const bool isPlaying = pos.isPlaying;

    // Ensure we allow MIDI out when the host is playing so external gear follows the DAW
    allowMidiOut = allowMidiOut || isPlaying;

    // Robust run state handling: don't miss edges that occur between blocks
    if (! runParamCached)
    {
        if (runActive || pendingStart)
        {
            // Stop immediately and cancel any pending start
            runActive = false;
            pendingStart = false;
            uiIsRunning.store(false, std::memory_order_relaxed);
            uiPendingStart.store(false, std::memory_order_relaxed);
            // When user has Run==off, suppress sending any MIDI stop messages.
        }
    }
    else // runParamCached == true
    {
        if (! runActive && ! pendingStart)
        {
            // Arm a start at the next bar if we're currently stopped
            pendingStart = true;
            uiPendingStart.store(true, std::memory_order_relaxed);
        }
    }
    // removed unused lastRunParam

    // Trigger mode rising edge while already running (engine active): schedule a bar+offset restart.
    // Placed before host transport edge handling so NEXT indicator can appear immediately after user toggles.
    {
        const bool tmNow = triggerModeEnabled.load(std::memory_order_relaxed);
        if (runActive && tmNow && ! lastTriggerModeEnabled)
        {
            pendingBarRestart.store(true, std::memory_order_relaxed);
            uiNextRestartPending.store(true, std::memory_order_relaxed);
        }
        lastTriggerModeEnabled = tmNow;
    }

    // Transport state transitions: emit Start/Continue/Stop when host play toggles
    int hostStartSampleThisBlock = -1; // if host started this block, mark sample 0 as a boundary (we'll allow a clock on this frame)
    bool hostForcedAllowMidiOut = false; // when host START occurs we temporarily allow MIDI clocks even if Run param is off
    bool haveHostStartMsg = false;
    juce::MidiMessage hostStartMsg;
    if (isPlaying && ! lastWasPlaying)
    {
        // Distinguish plugin load mid-transport vs genuine transport start edge.
        const double lastBarLocal = pos.ppqPositionOfLastBarStart;
        const double barLenQLocal = (pos.timeSigNumerator > 0 && pos.timeSigDenominator > 0)
            ? (4.0 * (double) pos.timeSigNumerator / (double) pos.timeSigDenominator)
            : 4.0;
        const double posInBar = juce::jlimit(0.0, barLenQLocal, ppqStart - lastBarLocal);
        int initialStep = (int) std::floor((barLenQLocal > 0.0 ? (posInBar / barLenQLocal) : 0.0) * 16.0) + 1;
        if (initialStep < 1) initialStep = 1; if (initialStep > 16) initialStep = 16;
        // Do not suppress Start on initial load: always treat a DAW transport START as a real
        // start event. Older behaviour suppressed Start if the plugin loaded mid-bar (firstBlock
        // && initialStep > 1) which prevented immediate clock emission. The user expects the
        // plugin to begin sending Start+clocks immediately when the DAW starts, so we always
        // proceed with the normal Start/Continue emission here.
        const bool atStart = (ppqStart < 1e-6);
        const auto startMsg = atStart ? juce::MidiMessage::midiStart() : juce::MidiMessage::midiContinue();
        // Always emit Start/Continue when host transport starts. Do not gate host START
        // behind the Run parameter — treat host as authoritative so downstream routing
        // receives proper transport messages immediately. Add the Start into the
        // internal buffer and mark it for external output later via extClock so we
        // only send a single Start to external devices (avoid duplicates).
        midi.addEvent(startMsg, 0);
        haveHostStartMsg = true;
        hostStartMsg = startMsg;
        // Ensure clocks are allowed this block even if the user Run param is off.
        hostForcedAllowMidiOut = true;
        runActive = true;
        pendingStart = false;
        uiIsRunning.store(true, std::memory_order_relaxed);
        uiPendingStart.store(false, std::memory_order_relaxed);
        hostStartSampleThisBlock = 0;
        uiStep16.store(1, std::memory_order_relaxed);
        firstBlock = false;
        // Reset accumulators on a host transport START
        resetAccumulators();
    }
    else if (! isPlaying && lastWasPlaying)
    {
        const auto stopMsg = juce::MidiMessage::midiStop();
        if (allowMidiOut || hostForcedAllowMidiOut)
        {
            midi.addEvent(stopMsg, 0);
            // queue external stop for one-shot flush at end
            extClock.addEvent(stopMsg, 0);
        }
        // When host stops, also clear run-active state
        runActive = false;
        pendingStart = false;
        uiIsRunning.store(false, std::memory_order_relaxed);
        uiPendingStart.store(false, std::memory_order_relaxed);
        // Reset accumulators on host STOP
        resetAccumulators();
    }

    // Generate clock ticks aligned to transport when playing
    if (isPlaying && std::isfinite(ppqStart))
    {
        const double ppqPerSample = 1.0 / samplesPerQuarter; // quarter-notes per sample
        const auto clockMsg = juce::MidiMessage::midiClock();
        // Update UI step (1..16) based on position within current bar.
        // If the next bar boundary falls within this block, force the UI to show step 1
        // so the visual starts at 12 o'clock on bar transitions that occur mid-block.
        const double lastBar = pos.ppqPositionOfLastBarStart;
        const double barLenQ = (pos.timeSigNumerator > 0 && pos.timeSigDenominator > 0)
            ? (4.0 * (double) pos.timeSigNumerator / (double) pos.timeSigDenominator)
            : 4.0;
        const double nextBar = lastBar + barLenQ;
        const double uiPpqEnd = ppqStart + (double) (numSamples - 1) * ppqPerSample;
        if (ppqStart < nextBar && nextBar <= uiPpqEnd)
        {
            uiStep16.store(1, std::memory_order_relaxed);
        }
        else
        {
            const double withinBar = juce::jlimit(0.0, barLenQ, ppqStart - lastBar);
            const double frac = (barLenQ > 0.0 ? withinBar / barLenQ : 0.0);
            int step = (int) std::floor(frac * 16.0) + 1;
            if (step < 1) step = 1; if (step > 16) step = 16;
            uiStep16.store(step, std::memory_order_relaxed);
        }

        // Helpers for computing tick indices under a given resolution
        auto tickAt = [](double ppq, int res) -> long long { return (long long) std::floor(ppq * (double) res); };

        // Handle pending shuffle (swing) parameter change: schedule at next unswung 1/8 (0.5 QN) boundary.
        // This preserves clock continuity: we switch swing only at 8th boundaries which are always "straight".
        if (auto* sh = dynamic_cast<juce::AudioParameterInt*>(parameters.getParameter(paramShuffleStep)))
        {
            const int desiredShuffle = juce::jlimit(1, 7, sh->get());
            if (desiredShuffle != currentShuffleStep && pendingShuffleStep != desiredShuffle)
            {
                pendingShuffleStep = desiredShuffle;
                // Compute next unswung 1/8 boundary (0.5 quarter-note increments)
                const double nextUnswingPair = std::floor(ppqStart / 0.5 + 1.0) * 0.5;
                applyShuffleAtPPQ = nextUnswingPair;
                uiNextRestartPending.store(true, std::memory_order_relaxed); // show NEXT while waiting
            }
        }

        // Handle immediate retrigger (1/16) and bar-aligned changes (swing applied when computing sample offsets)
        // extClock is declared at function scope to collect external messages from all branches.
        int gapStart = -1, gapEnd = -1, startSampleAtBoundary = -1;
        int forbiddenClockSample = -1; // do not emit clock on this exact sample (Start sample)

        // Latent 1/16 grid Start: we always know next grid boundary; emit Start only if armed
        if (runActive)
        {
            // Swing-aware 16th boundaries: if shuffle active (>1) and bar length is 4/4, use shifted boundary set.
            const double eps = 1.0e-6;
            const double lastBar = pos.ppqPositionOfLastBarStart;
            const double barLenQ = (pos.timeSigNumerator > 0 && pos.timeSigDenominator > 0)
                ? (4.0 * (double) pos.timeSigNumerator / (double) pos.timeSigDenominator)
                : 4.0;
            double withinBar = juce::jlimit(0.0, barLenQ, ppqStart - lastBar);
            double nextBoundaryQ = -1.0;
            if (currentShuffleStep > 1 && std::fabs(barLenQ - 4.0) < 1e-6)
            {
                const double shiftQ = (double)(currentShuffleStep - 1) * (1.0 / 48.0);
                // Build 16 boundary positions inside a 4/4 bar considering swing pair lengths (pairLen remains 0.5 QN):
                // Even index (0,2,4,...) => pairStart; odd => pairStart + 0.25 + shiftQ.
                double found = -1.0;
                for (int pair = 0; pair < 8; ++pair)
                {
                    double pairStart = pair * 0.5; // cumulative (two 16ths total 0.5 QN)
                    double firstBoundary = pairStart;            // step 2*pair+1 (1-based)
                    double secondBoundary = pairStart + 0.25 + shiftQ; // step 2*pair+2 (1-based)
                    if (firstBoundary >= withinBar - eps && found < 0.0) found = firstBoundary;
                    if (secondBoundary >= withinBar - eps && found < 0.0) found = secondBoundary;
                }
                if (found < 0.0)
                    found = 4.0; // wrap to bar end (next bar start)
                nextBoundaryQ = lastBar + found;
            }
            else
            {
                // Unswing grid
                const double gridQ = kSixteenthQ; // 0.25
                const double mod = std::fmod(ppqStart, gridQ);
                const bool onGrid = std::fabs(mod) <= eps || std::fabs(mod - gridQ) <= eps;
                const double nextGrid = onGrid ? ppqStart : (std::floor(ppqStart / gridQ) + 1.0) * gridQ;
                nextBoundaryQ = nextGrid;
            }
            const double deltaQ = juce::jmax(0.0, nextBoundaryQ - ppqStart);
            const int nextGridOffset = fastRoundPositive(deltaQ * samplesPerQuarter);
            if (triggerArmedForNextSixteenth.load(std::memory_order_relaxed))
            {
                if (nextGridOffset >= 0 && nextGridOffset < numSamples)
                {
                    const auto startMsg = juce::MidiMessage::midiStart();
                    addBoth(midi, extClock, startMsg, nextGridOffset);
                        // record that we emitted a Start from a manual trigger at this sample
                        lastPatternStartSampleInBlock = nextGridOffset;
                    // triggerArmed diagnostic message removed per user request
                    // Consume arm; optional bar restart if trigger mode enabled
                    triggerArmedForNextSixteenth.store(false, std::memory_order_relaxed);
                    if (triggerModeEnabled.load(std::memory_order_relaxed))
                    {
                        pendingBarRestart.store(true, std::memory_order_relaxed);
                        // Schedule restart at next occurrence of step within bar (modulo)
                        uiNextRestartPending.store(true, std::memory_order_relaxed);
                    }
                    // Allow clock at same frame (no suppression)
                }
                // If offset beyond block, keep armed until next block (no change)
            }
        }

        // Pattern scheduling: at bar boundaries decide if pattern fires; then emit Start events at active step PPQ times as they fall in this block.
        tryFirePattern(ppqStart, barLenQ, lastBar, numSamples, midi, extClock);

        auto barWindow = handleBarAlignedChanges(pos, numSamples, midi, extClock);
        gapStart = barWindow.gapStart;
        gapEnd = barWindow.gapEnd;
        startSampleAtBoundary = barWindow.startSample;
        // Re-run pattern scheduling after applying bar-aligned changes in case a restart or Run state
        // was enabled by `handleBarAlignedChanges` earlier in this block. tryFirePattern is idempotent
        // because it consumes pendingPatternPPQ and checks lastPatternFiredBar.
        tryFirePattern(ppqStart, barLenQ, lastBar, numSamples, midi, extClock);

        // If host just started this block (sample 0), mark the boundary at sample 0
        if (startSampleAtBoundary < 0 && hostStartSampleThisBlock >= 0)
            startSampleAtBoundary = hostStartSampleThisBlock;

        // Also merge host Start/Continue into extClock at sample 0 so the following clock can share the same frame
        if (haveHostStartMsg)
            extClock.addEvent(hostStartMsg, 0);

        // If a plugin-driven boundary Start requires suppression, set forbidden sample (not set for bar-restart/change-rate)
        if (suppressClockAtBoundaryOnce && startSampleAtBoundary >= 0)
            forbiddenClockSample = startSampleAtBoundary;

        const bool boundaryInBlock = (startSampleAtBoundary >= 0);
        const int resolutionAfter = getClockResolution(); // may change if rate applied at boundary

        // Precompute several constants used inside the tick loops to reduce per-tick overhead.
        const double ppqBlockEnd = ppqStart + (double) (numSamples - 1) * ppqPerSample;
        if (lastTickIndex == std::numeric_limits<long long>::min())
            lastTickIndex = tickAt(ppqStart, resolutionBefore) - 1;

        // Precompute swing/pulse mapping constants for the "before" resolution
        const double pairLenQBefore = 0.5;
        const double shiftQBefore = (currentShuffleStep <= 1) ? 0.0 : (double)(currentShuffleStep - 1) * (1.0 / 48.0);
        const long long pulsesPerPairBefore = (long long) std::llround(pairLenQBefore * (double) resolutionBefore);
        const int pulsesPer16thBefore = (int) (pulsesPerPairBefore / 2);
        const double firstLenBefore = 0.25 + shiftQBefore;
        const double secondLenBefore = 0.25 - shiftQBefore;
        const double spacingFirstBefore = pulsesPer16thBefore > 0 ? (firstLenBefore / (double) pulsesPer16thBefore) : 0.0;
        const double spacingSecondBefore = pulsesPer16thBefore > 0 ? (secondLenBefore / (double) pulsesPer16thBefore) : 0.0;

        // Use persistent per-primary fractional accumulator (declared in header).
        // Note: conservative persistence (carries across blocks) but reset on transport/bpm/sample-rate/rate changes.

        // Phase 1: ticks before a restart boundary (or whole block if no restart boundary). May include a mid-block shuffle activation.
        const int preEndSample = boundaryInBlock ? (startSampleAtBoundary - 1) : (numSamples - 1);
        if (preEndSample >= 0)
        {
            const double ppqPreEnd = ppqStart + (double) preEndSample * ppqPerSample;
            const long long tickIndexEndPre   = tickAt(ppqPreEnd, resolutionBefore);
            long long lastProcessedT = lastTickIndex;
            // Always continue from lastTickIndex+1 to preserve carried ticks across blocks
            for (long long t = lastTickIndex + 1; t <= tickIndexEndPre; ++t)
            {
                double rawTickPPQ = (double) t / (double) resolutionBefore;

                // Activate pending shuffle at unswung 1/8 boundary
                if (pendingShuffleStep > 0 && applyShuffleAtPPQ >= 0.0 && rawTickPPQ >= applyShuffleAtPPQ)
                {
                    currentShuffleStep = pendingShuffleStep;
                    pendingShuffleStep = -1;
                    applyShuffleAtPPQ = -1.0;
                    uiNextRestartPending.store(false, std::memory_order_relaxed);
                }

                // Optimised swing mapping using precomputed constants (reduces per-tick overhead)
                long long pairIndex = 0;
                int indexInPair = 0;
                if (pulsesPerPairBefore > 0)
                {
                    pairIndex = t / pulsesPerPairBefore;
                    indexInPair = (int) (t % pulsesPerPairBefore);
                }
                double tickPPQ;
                if (currentShuffleStep <= 1)
                {
                    tickPPQ = (double) t / (double) resolutionBefore;
                }
                else
                {
                    double pairStart = (double) pairIndex * pairLenQBefore;
                    if (indexInPair < pulsesPer16thBefore)
                        tickPPQ = pairStart + (double) indexInPair * spacingFirstBefore;
                    else
                    {
                        const int idxSecond = indexInPair - pulsesPer16thBefore;
                        tickPPQ = pairStart + firstLenBefore + (double) idxSecond * spacingSecondBefore;
                    }
                }
                const double deltaQuarter = tickPPQ - ppqStart;
                const double exactSample = deltaQuarter * samplesPerQuarter;

                // Treat the first pulse inside each pair as a primary and apply a tiny per-block fractional accumulator
                // to stabilise rounding on these primaries (clamped per-block, no carry across blocks).
                int mappedOffset;
                if (indexInPair == 0)
                {
                    double adj = exactSample + fracAccPrimaryBefore;
                    mappedOffset = fastRoundPositive(adj);
                    fracAccPrimaryBefore = adj - (double) mappedOffset;
                    // clamp carry to avoid large spikes
                    if (fracAccPrimaryBefore > 0.5) fracAccPrimaryBefore = 0.5;
                    if (fracAccPrimaryBefore < -0.5) fracAccPrimaryBefore = -0.5;
                }
                else
                {
                    mappedOffset = fastRoundPositive(exactSample);
                }
                // If mapped clock lands beyond this pre-boundary region, carry it to next block (do not clamp/emit)
                if (mappedOffset > preEndSample)
                {
                    break; // leave lastProcessedT unchanged so t will be retried next block
                }
                const int sampleOffset = juce::jlimit(0, numSamples - 1, mappedOffset);
                const bool inGapBar = (gapStart >= 0 && sampleOffset >= gapStart && sampleOffset < gapEnd);
                const bool onForbidden = (forbiddenClockSample >= 0 && sampleOffset == forbiddenClockSample);
                const bool inGap = inGapBar;
                if (! suppressUntilRestart && ! inGap && ! onForbidden)
                {
                    if (allowMidiOut || hostForcedAllowMidiOut)
                    {
                        midi.addEvent(clockMsg, sampleOffset);
                        uiClockCounter.fetch_add(1, std::memory_order_relaxed);
                        if (externalMidiOut)
                            extClock.addEvent(clockMsg, sampleOffset);
                        // pre-phase diag logging removed per user request
                    }
                }
                if (diagnosticsEnabled && diagPairsRemaining > 0)
                {
                    const long long pairIdx = (long long) std::floor((tickPPQ - lastBar) / 0.5);
                    const double norm = (tickPPQ - lastBar) / juce::jmax(1e-9, barLenQ);
                    const double shiftQCur = currentShuffleStep <= 1 ? 0.0 : (double)(currentShuffleStep - 1) * (1.0 / 48.0);
                    if (pairIdx != diagLastLoggedPair)
                    {
                            // pair pre-phase diagnostic removed per user request
                        diagLastLoggedPair = pairIdx;
                        --diagPairsRemaining;
                        diagLastSample = -1;
                    }
                        // per-pulse diagnostic removed per user request
                    diagLastSample = sampleOffset;
                }
                    if (clickEnabled)
                    {
                        int stepSpan = 1;
                        switch (clickRateCached)
                        {
                            case 1: stepSpan = resolutionBefore; break;                 // quarter note
                            case 2: stepSpan = juce::jmax(1, resolutionBefore / 2); break; // eighth
                            case 3: stepSpan = juce::jmax(1, resolutionBefore / 4); break; // sixteenth
                            case 4: stepSpan = 1; break; // every midi-clock pulse (24ppq)
                            default: stepSpan = juce::jmax(1, resolutionBefore / 4); break;
                        }
                        if ((t % stepSpan) == 0)
                        {
                            const bool quarterBoundary = (t % resolutionBefore) == 0;
                            const float baseLevel = quarterBoundary ? 1.0f : 0.7f;
                            const float outLevel = baseLevel * clickGainLinear;
                            const int pulseSamples = (int) juce::jmax(1, (int) std::round(0.001 * currentSampleRate));
                            if (! clickPulseCached)
                            {
                                // 1-sample spike
                                if (sampleOffset >= 0 && sampleOffset < numSamples)
                                {
                                    for (int ch = 0; ch < buffer.getNumChannels(); ++ch)
                                        buffer.addSample(ch, sampleOffset, outLevel);
                                }
                            }
                            else
                            {
                                // 1ms pulse: distribute a decaying linear pulse across pulseSamples
                                for (int s = 0; s < pulseSamples; ++s)
                                {
                                    const int idx = sampleOffset + s;
                                    if (idx >= 0 && idx < numSamples)
                                    {
                                        const float env = 1.0f - (float) s / (float) pulseSamples;
                                        const float val = outLevel * env;
                                        for (int ch = 0; ch < buffer.getNumChannels(); ++ch)
                                            buffer.addSample(ch, idx, val);
                                    }
                                }
                            }
                        }
                    }
                lastProcessedT = t;
            }
            lastTickIndex = lastProcessedT;
        }

        // Precompute 'after' resolution swing/pulse mapping constants for use in the post-boundary loop
        const double pairLenQAfter = 0.5;
        const double shiftQAfter = (currentShuffleStep <= 1) ? 0.0 : (double)(currentShuffleStep - 1) * (1.0 / 48.0);
        const long long pulsesPerPairAfter = (long long) std::llround(pairLenQAfter * (double) resolutionAfter);
        const int pulsesPer16thAfter = (int) (pulsesPerPairAfter > 0 ? (pulsesPerPairAfter / 2) : 0);
        const double firstLenAfter = 0.25 + shiftQAfter;
        const double secondLenAfter = 0.25 - shiftQAfter;
        const double spacingFirstAfter = pulsesPer16thAfter > 0 ? (firstLenAfter / (double) pulsesPer16thAfter) : 0.0;
        const double spacingSecondAfter = pulsesPer16thAfter > 0 ? (secondLenAfter / (double) pulsesPer16thAfter) : 0.0;

        // Phase 2: ticks after a restart boundary using the (possibly) new resolution.
        if (boundaryInBlock)
        {
            // Reset tick baseline to the boundary in "after" resolution so first tick lands exactly 1/res after Start
            const double boundaryPPQ = ppqStart + (double) startSampleAtBoundary * ppqPerSample;
            const long long baseIdx = tickAt(boundaryPPQ, resolutionAfter);
            if (suppressClockAtBoundaryOnce)
            {
                // Skip the clock at the exact Start frame; next tick will be at baseIdx + 1
                lastTickIndex = baseIdx;
            }
            else
            {
                lastTickIndex = baseIdx - 1;
            }

            const long long tickIndexEndPost   = tickAt(ppqBlockEnd,  resolutionAfter);
            long long lastProcessedT = lastTickIndex;
            for (long long t = lastTickIndex + 1; t <= tickIndexEndPost; ++t)
            {
                double rawTickPPQ = (double) t / (double) resolutionAfter;
                if (pendingShuffleStep > 0 && applyShuffleAtPPQ >= 0.0 && rawTickPPQ >= applyShuffleAtPPQ)
                {
                    currentShuffleStep = pendingShuffleStep;
                    pendingShuffleStep = -1;
                    applyShuffleAtPPQ = -1.0;
                    uiNextRestartPending.store(false, std::memory_order_relaxed);
                }
                double tickPPQ = 0.0;
                int indexInPair = 0;
                if (currentShuffleStep <= 1 || pulsesPerPairAfter <= 0)
                {
                    tickPPQ = (double) t / (double) resolutionAfter;
                }
                else
                {
                    const long long pairIndex = t / pulsesPerPairAfter;
                    indexInPair = (int) (t % pulsesPerPairAfter);
                    double pairStart = (double) pairIndex * pairLenQAfter;
                    if (indexInPair < pulsesPer16thAfter)
                        tickPPQ = pairStart + (double) indexInPair * spacingFirstAfter;
                    else
                    {
                        const int idxSecond = indexInPair - pulsesPer16thAfter;
                        tickPPQ = pairStart + firstLenAfter + (double) idxSecond * spacingSecondAfter;
                    }
                }
                const double deltaQuarter = tickPPQ - ppqStart;
                const double exactSample = deltaQuarter * samplesPerQuarter;
                int mappedOffset;
                if (currentShuffleStep > 1 && pulsesPerPairAfter > 0 && indexInPair == 0)
                {
                    double adj = exactSample + fracAccPrimaryAfter;
                    mappedOffset = fastRoundPositive(adj);
                    fracAccPrimaryAfter = adj - (double) mappedOffset;
                    if (fracAccPrimaryAfter > 0.5) fracAccPrimaryAfter = 0.5;
                    if (fracAccPrimaryAfter < -0.5) fracAccPrimaryAfter = -0.5;
                }
                else
                {
                    mappedOffset = fastRoundPositive(exactSample);
                }
                if (mappedOffset > numSamples - 1)
                {
                    break; // carry into next block; do not advance lastTickIndex
                }
                const int sampleOffset = juce::jlimit(0, numSamples - 1, mappedOffset);
                // Past boundary; optionally suppress clock on the exact Start frame to avoid double clocks with Start
                if (! suppressUntilRestart && !(forbiddenClockSample >= 0 && sampleOffset == forbiddenClockSample))
                {
                    if (allowMidiOut || hostForcedAllowMidiOut)
                    {
                        midi.addEvent(clockMsg, sampleOffset);
                        uiClockCounter.fetch_add(1, std::memory_order_relaxed);
                        if (externalMidiOut)
                            extClock.addEvent(clockMsg, sampleOffset);
                        // post-phase diag logging removed per user request
                    }
                }
                if (diagnosticsEnabled && diagPairsRemaining > 0)
                {
                    const long long pairIdx = (long long) std::floor((tickPPQ - lastBar) / 0.5);
                    const double norm = (tickPPQ - lastBar) / juce::jmax(1e-9, barLenQ);
                    const double shiftQCur = currentShuffleStep <= 1 ? 0.0 : (double)(currentShuffleStep - 1) * (1.0 / 48.0);
                    // post-phase pair/pulse diagnostics removed per user request
                    diagLastLoggedPair = pairIdx;
                    --diagPairsRemaining;
                    diagLastSample = sampleOffset;
                }
                    if (clickEnabled)
                    {
                        int stepSpan = 1;
                        switch (clickRateCached)
                        {
                            case 1: stepSpan = resolutionAfter; break;
                            case 2: stepSpan = juce::jmax(1, resolutionAfter / 2); break;
                            case 3: stepSpan = juce::jmax(1, resolutionAfter / 4); break;
                            case 4: stepSpan = 1; break;
                            default: stepSpan = juce::jmax(1, resolutionAfter / 4); break;
                        }
                        if ((t % stepSpan) == 0)
                        {
                            const bool quarterBoundary = (t % resolutionAfter) == 0;
                            const float baseLevel = quarterBoundary ? 1.0f : 0.7f;
                            const float outLevel = baseLevel * clickGainLinear;
                            const int pulseSamples = (int) juce::jmax(1, (int) std::round(0.001 * currentSampleRate));
                            if (! clickPulseCached)
                            {
                                if (mappedOffset >= 0 && mappedOffset < numSamples)
                                {
                                    for (int ch = 0; ch < buffer.getNumChannels(); ++ch)
                                        buffer.addSample(ch, mappedOffset, outLevel);
                                }
                            }
                            else
                            {
                                for (int s = 0; s < pulseSamples; ++s)
                                {
                                    const int idx = mappedOffset + s;
                                    if (idx >= 0 && idx < numSamples)
                                    {
                                        const float env = 1.0f - (float) s / (float) pulseSamples;
                                        const float val = outLevel * env;
                                        for (int ch = 0; ch < buffer.getNumChannels(); ++ch)
                                            buffer.addSample(ch, idx, val);
                                    }
                                }
                            }
                        }
                    }
                lastProcessedT = t;
            }
            lastTickIndex = lastProcessedT;
            // Consume the one-shot suppression
            suppressClockAtBoundaryOnce = false;
        }

        // extClock will be flushed once after scheduling (below)
    }

    // Flush any queued external MIDI messages gathered while scheduling.
    if (externalMidiOut && extClock.getNumEvents() > 0)
        externalMidiOut->sendBlockOfMessages(extClock, juce::Time::getMillisecondCounterHiRes(), currentSampleRate);

    // Per-tick clicks are written directly into the audio buffer in the scheduling loops above.

    lastWasPlaying = isPlaying;
    // Offset step change: schedule restart at the next occurrence of the selected step (modulo bar)
    if (auto* pi = dynamic_cast<juce::AudioParameterInt*>(parameters.getParameter(paramResyncOffsetStep)))
    {
        const int cur = juce::jlimit(1, 16, pi->get());
        if (cur != lastOffsetStep)
        {
            lastOffsetStep = cur;
            pendingBarRestart.store(true, std::memory_order_relaxed);
            // no force to next bar; modulo handling in handleBarAlignedChanges
            uiNextRestartPending.store(true, std::memory_order_relaxed);
        }
    }
}

// ---- Pattern helpers ----
void ClockSyncAudioProcessor::updatePatternParams()
{
    if (auto* pb = dynamic_cast<juce::AudioParameterChoice*>(parameters.getParameter(paramPatternBars)))
        patternBarsMode.store(pb->getIndex(), std::memory_order_relaxed);
    if (auto* ps = dynamic_cast<juce::AudioParameterInt*>(parameters.getParameter(paramPatternSteps)))
        patternStepsMask.store((uint16_t) juce::jlimit(0, 65535, ps->get()), std::memory_order_relaxed);
}

int ClockSyncAudioProcessor::getPatternBarIntervalFromMode(int mode) const
{
    switch (mode)
    {
        case 1: return 1; // index 1 => bar interval 1
        case 2: return 2;
        case 3: return 4;
        case 4: return 8;
        case 5: return 16;
        case 6: return 32;
        case 7: return 64;
        default: return -1; // 0=OFF or RND (8) handled separately
    }
}

void ClockSyncAudioProcessor::preparePatternForBar(double barStartPPQ, double barLenQ)
{
    pendingPatternPPQ.clear();
    const uint16_t mask = patternStepsMask.load(std::memory_order_relaxed);
    if (mask == 0) return; // nothing active
    // Visual interaction applies a +4 step rotation (see PatternRing::hitTest). The stored bitmask indices
    // therefore represent (logicalIndex + 4) & 15. To schedule pattern events at the intended logical
    // 16th positions we inverse that rotation here.
    constexpr int visualRotation = 4; // must match PatternRing rotation offset
    const bool applySwing = (currentShuffleStep > 1 && std::fabs(barLenQ - 4.0) < 1e-6);
    const double shiftQ = applySwing ? (double)(currentShuffleStep - 1) * (1.0 / 48.0) : 0.0; // second 16th of each pair delay
    for (int logicalIndex = 0; logicalIndex < 16; ++logicalIndex)
    {
        const int storedIndex = (logicalIndex + visualRotation) & 15; // how it's stored in the mask
        if ((mask & (uint16_t(1) << storedIndex)) == 0) continue;
        // The stored bit represents a step at `logicalIndex`. Schedule the
        // firing exactly at the matching logical index so step 1 falls on DAW
        // step 1 (no -1 shift). This keeps playback aligned with the host.
        const int triggerLogical = logicalIndex; // exact logical index
        double stepPosQ;
        if (applySwing)
        {
            int pairIndex = triggerLogical / 2; // 0..7
            bool secondInPair = (triggerLogical & 1) == 1;
            double pairStart = pairIndex * 0.5; // each pair spans 0.5 QN
            stepPosQ = secondInPair ? (pairStart + 0.25 + shiftQ) : pairStart;
        }
        else
        {
            // Unswing grid fallback (covers non-4/4 or shuffleStep==1)
            stepPosQ = (barLenQ / 16.0) * (double) triggerLogical;
        }
        pendingPatternPPQ.push_back(barStartPPQ + stepPosQ);
    }
    std::sort(pendingPatternPPQ.begin(), pendingPatternPPQ.end());
}

void ClockSyncAudioProcessor::tryFirePattern(double ppqStart, double barLenQ, double barStartPPQ, int numSamples, juce::MidiBuffer& midi, juce::MidiBuffer& extClock)
{
    // Allow pattern-driven Starts to fire even when the internal `runActive` flag
    // is false. This makes pattern behaviour consistent with manual triggers: when
    // a pattern step issues a Start it should put the engine into the running
    // state immediately so any scheduled bar-aligned restarts take effect in
    // the same block. We still honour the Pattern Bars mode being OFF below.
    const int mode = patternBarsMode.load(std::memory_order_relaxed);
    if (mode == 0) return; // OFF
    const bool rnd = (mode == 8);
    // Determine whether the current or upcoming bar should trigger the pattern.
    // Previously pattern preparation only ran when the block began exactly at a bar start.
    // Prepare the pattern for the current bar if it should fire and hasn't been prepared yet
    // (this allows scheduling of steps that fall later in the same bar even if the block
    // started after the bar start).
    const long long currentBar = computeCurrentBar(ppqStart, barLenQ);
    auto decideFireForBar = [&](long long candidateBar)->bool {
        if (rnd)
        {
            if (nextRandomPatternTargetBar < 0 || candidateBar >= nextRandomPatternTargetBar)
                return true;
            return false;
        }
        else
        {
            int interval = getPatternBarIntervalFromMode(mode);
            return (interval > 0 && (candidateBar % interval) == 0);
        }
    };

    if (decideFireForBar(currentBar) && lastPatternFiredBar != currentBar)
    {
        const double currentBarStartPPQ = (double) currentBar * barLenQ;
        lastPatternFiredBar = currentBar;
        preparePatternForBar(currentBarStartPPQ, barLenQ);
    }

    // Determine whether a bar boundary (one or more) falls within this audio block.
    // The original implementation only prepared patterns when the block started exactly at a bar start
    // (ppqStart == barStartPPQ), which misses cases where the bar start is inside the block. We detect
    // candidate bar-start PPQ positions inside the block and prepare the pattern for the exact bar that fires.
    const double eps = 1e-6;
    const double ppqPerSample = 1.0 / samplesPerQuarter;
    const double blockEndPPQ = ppqStart + (double)(numSamples - 1) * ppqPerSample;

    auto considerBarStart = [&](double candidateBarStartPPQ)
    {
        const long long candidateBar = computeCurrentBar(candidateBarStartPPQ, barLenQ);
        bool fire = false;
        if (rnd)
        {
            if (nextRandomPatternTargetBar < 0 || candidateBar >= nextRandomPatternTargetBar)
            {
                int interval = 1 + (int) (juce::Random::getSystemRandom().nextInt(16));
                nextRandomPatternTargetBar = candidateBar + interval;
                fire = true;
            }
        }
        else
        {
            int interval = getPatternBarIntervalFromMode(mode);
            if (interval > 0 && (candidateBar % interval) == 0)
                fire = true;
        }
        if (fire)
        {
            lastPatternFiredBar = candidateBar;
            preparePatternForBar(candidateBarStartPPQ, barLenQ);
        }
    };

    // If the block begins exactly at a bar start, consider that bar.
    if (std::fabs(ppqStart - barStartPPQ) < eps)
        considerBarStart(barStartPPQ);

    // Consider any future bar starts that fall within this block (typically only the next bar).
    double nextBar = barStartPPQ + barLenQ;
    while (nextBar <= blockEndPPQ + eps)
    {
        if (nextBar >= ppqStart - eps)
            considerBarStart(nextBar);
        nextBar += barLenQ;
    }
    if (pendingPatternPPQ.empty()) return;
    // Emit Start messages for pattern PPQ times that fall within this block; remove them after emission.
    auto clockResolution = getClockResolution(); // not strictly needed
    std::vector<double> remaining;
    remaining.reserve(pendingPatternPPQ.size());
    for (double targetPPQ : pendingPatternPPQ)
    {
        if (targetPPQ < ppqStart - 1e-9) continue; // already passed (late)
        if (targetPPQ > blockEndPPQ + 1e-9) { remaining.push_back(targetPPQ); continue; }
        double deltaQ = targetPPQ - ppqStart;
        int sampleOffset = fastRoundPositive(deltaQ * samplesPerQuarter);
        if (sampleOffset < 0 || sampleOffset >= numSamples) { remaining.push_back(targetPPQ); continue; }
        const auto startMsg = juce::MidiMessage::midiStart();
        // If the bar-restart path already emitted/consumed a Start at this sample,
        // avoid sending a duplicate and consume the pending indicators so UI/state
        // reflect the applied restart.
        if (sampleOffset == lastBarRestartStartSampleInBlock)
        {
            pendingBarRestart.store(false, std::memory_order_relaxed);
            uiNextRestartPending.store(false, std::memory_order_relaxed);
            // Clear any deferred pattern restart target to avoid re-scheduling.
            pendingPatternRestartTargetBar.store(-1, std::memory_order_relaxed);
            continue;
        }
        midi.addEvent(startMsg, sampleOffset);
        extClock.addEvent(startMsg, sampleOffset);
        // record this sample so the bar-restart handler can avoid emitting a duplicate Start
        lastPatternStartSampleInBlock = sampleOffset;
        // When a pattern issues a Start we want the processor/UI internal
        // state to reflect that Start immediately so the visual step and
        // subsequent scheduling align with the emitted Start (matches manual trigger).
        // Compute the logical step (1..16) inside the bar for this targetPPQ and
        // update UI/run state accordingly.
        if (barLenQ > 0.0)
        {
            double posInBar = targetPPQ - barStartPPQ;
            // wrap into 0..barLenQ range
            while (posInBar < 0.0) posInBar += barLenQ;
            while (posInBar >= barLenQ) posInBar -= barLenQ;
            const double frac = posInBar / barLenQ;
            int stepNumber = (int) std::floor(frac * 16.0) + 1;
            if (stepNumber < 1) stepNumber = 1;
            if (stepNumber > 16) stepNumber = 16;
            uiStep16.store(stepNumber, std::memory_order_relaxed);
        }
        // Make the processor consider itself running so any restart/modifiers take effect.
        runActive = true;
        pendingStart = false;
        uiIsRunning.store(true, std::memory_order_relaxed);
        uiPendingStart.store(false, std::memory_order_relaxed);
        // tryFirePattern diagnostic logging removed per user request
        // Respect trigger mode: schedule a bar+offset restart (same semantics as manual trigger idx1)
        const long long patternBar = computeCurrentBar(targetPPQ, barLenQ);
        if (triggerModeEnabled.load(std::memory_order_relaxed) && lastPatternRestartScheduledBar != patternBar)
        {
            // Defer actual restart application until the pattern play finishes.
            // Compute a target bar where the restart should occur: prefer the pattern's
            // configured bars interval if available; otherwise schedule next bar.
            int interval = getPatternBarIntervalFromMode(mode);
            long long targetBar = patternBar + (interval > 0 ? (long long) interval : 1LL);
            pendingPatternRestartTargetBar.store(targetBar, std::memory_order_relaxed);
            uiNextRestartPending.store(true, std::memory_order_relaxed);
            lastPatternRestartScheduledBar = patternBar;
        }
    }
    pendingPatternPPQ.swap(remaining);
}

ClockSyncAudioProcessor::BarRestartWindow ClockSyncAudioProcessor::handleBarAlignedChanges(const juce::AudioPlayHead::CurrentPositionInfo& pos,
                                                                                           int numSamples,
                                                                                           juce::MidiBuffer& midi,
                                                                                           juce::MidiBuffer& extBuffer)
{
    BarRestartWindow window;
    const bool runWasActive = runActive;

    // Local snapshot: only send MIDI messages for restarts if Run is enabled or ClockWhileStopped is enabled
    const bool sendMidi = (parameters.getRawParameterValue(paramRun)->load() > 0.5f)
                          || (parameters.getRawParameterValue(paramClockWhileStopped)->load() > 0.5f);

    const double lastBar = pos.ppqPositionOfLastBarStart;
    const double barLenQ = (pos.timeSigNumerator > 0 && pos.timeSigDenominator > 0)
        ? (4.0 * (double) pos.timeSigNumerator / (double) pos.timeSigDenominator)
        : 4.0;
    const double ppqStart = pos.ppqPosition;
    const double posInBar = juce::jlimit(0.0, barLenQ, ppqStart - lastBar);
    double remainQ = barLenQ - posInBar;
    if (remainQ < 0.0) remainQ += barLenQ;
    // Default boundary at next bar start
    int sampleOffset = fastRoundPositive(remainQ * samplesPerQuarter);
    if (sampleOffset < 0) sampleOffset = 0;

    const bool haveRateChange = (pendingRateIndex >= 0);
    const bool haveShuffleChange = (pendingShuffleStep > 0); // shuffle by itself should NOT force a restart now
    const bool haveStart = pendingStart;
    const bool haveBarRestart = pendingBarRestart.load(std::memory_order_relaxed);
    const bool havePatternDeferred = (pendingPatternRestartTargetBar.load(std::memory_order_relaxed) >= 0);
    const bool applyShuffleWithBoundary = haveShuffleChange && (haveRateChange || haveStart || haveBarRestart || havePatternDeferred);

    // Compute the next occurrence of the selected step (1..16) at or after 'now'.
    // If the selected step lies ahead in the current bar, use it; otherwise target the same step in the next bar.
    int offsetStep = 1;
    if (auto* pi = dynamic_cast<juce::AudioParameterInt*>(parameters.getParameter(paramResyncOffsetStep)))
        offsetStep = juce::jlimit(1, 16, pi->get());
    else if (auto* p = parameters.getParameter(paramResyncOffsetStep))
        offsetStep = juce::jlimit(1, 16, (int) juce::roundToInt(p->getValue() * 15.0f + 1.0f));
    const int stepIndex0 = offsetStep - 1; // 0..15
    // Swing-aware mapping: if shuffle active (>1) and 4/4, recompute target boundary using shifted second 16th lengths.
    double stepQWithinBar = (barLenQ / 16.0) * (double) stepIndex0; // default unswung
    if (currentShuffleStep > 1 && std::fabs(barLenQ - 4.0) < 1e-6)
    {
        const double shiftQ = (double)(currentShuffleStep - 1) * (1.0 / 48.0);
        int pairIndex = stepIndex0 / 2; // 0..7
        bool secondHalf = (stepIndex0 % 2) == 1;
        double pairStart = pairIndex * 0.5; // pair length always 0.5 quarter
        stepQWithinBar = secondHalf ? (pairStart + 0.25 + shiftQ) : pairStart;
    }

    // Local flag to record whether a deferred pattern-requested restart matches
    // the scheduled boundary calculated below.
    bool deferredMatches = false;
    long long scheduledRestartBar = -1;

    if (haveStart || haveBarRestart || haveRateChange || havePatternDeferred) // exclude pure shuffle change
    {
        // Schedule at the next occurrence of the selected step within the bar (modulo behavior)
        double deltaQ = stepQWithinBar - posInBar;
        if (deltaQ < -kBarEps)
            deltaQ += barLenQ; // wrap into the next bar if passed
        if (posInBar <= kBarEps && stepIndex0 == 0)
            deltaQ = 0.0; // allow immediate restart at bar start when offset=1

        sampleOffset = fastRoundPositive(deltaQ * samplesPerQuarter);
        // Determine which bar this scheduled restart will fall into. If a pattern
        // previously requested a deferred restart for that bar, mark the deferred
        // match so the restart is applied (and consume the deferred request).
        const long long scheduledRestartBar = computeCurrentBar(ppqStart + deltaQ + 1e-9, barLenQ);
        const long long pendingTarget = pendingPatternRestartTargetBar.load(std::memory_order_relaxed);
        const bool deferredMatches = (pendingTarget >= 0 && pendingTarget == scheduledRestartBar);
        if (deferredMatches)
            pendingPatternRestartTargetBar.store(-1, std::memory_order_relaxed);
    }

    if (sampleOffset <= numSamples - 1 && (haveRateChange || haveStart || haveBarRestart || deferredMatches))
    {
        jassert(sampleOffset >= 0); // debug-only: ensure non-negative scheduling
        // Gap length: use actual preceding 16th length under swing if possible (approx samples spanning previous half).
        double prevSixteenthLenQ = kSixteenthQ;
        if (currentShuffleStep > 1 && std::fabs(barLenQ - 4.0) < 1e-6)
        {
            // Determine which 16th we restart at; previous length depends on whether this is second or first in pair.
            bool secondHalf = (stepIndex0 % 2) == 1;
            const double shiftQ = (double)(currentShuffleStep - 1) * (1.0 / 48.0);
            prevSixteenthLenQ = secondHalf ? (0.25 + shiftQ) : (0.25 - shiftQ); // length of the preceding 16th segment
        }
        // Legacy mode emits a Stop a few ticks before Start and gates clocks between.
        // Modern mode skips the pre-Stop (continuous clock, no gap) but still emits Start.
        const bool legacy = legacyModeEnabled.load(std::memory_order_relaxed);
        int stopOffset = -1;
        if (legacy)
        {
            const int gapSamples = juce::jmax(1, fastRoundPositive(prevSixteenthLenQ * samplesPerQuarter) - 1);
            stopOffset = juce::jmax(0, sampleOffset - gapSamples);
            if (stopOffset >= sampleOffset)
                stopOffset = juce::jmax(0, sampleOffset - 1);
            if (stopOffset < sampleOffset)
            {
                const auto stopMsg = juce::MidiMessage::midiStop();
                if (sendMidi)
                {
                    midi.addEvent(stopMsg, stopOffset);
                    extBuffer.addEvent(stopMsg, stopOffset);
                }
            }
        }
        // Always emit Start (both modes)
        const auto startMsg = juce::MidiMessage::midiStart();
        // If a pattern already emitted a Start at this exact sample earlier in
        // the block, avoid sending a duplicate Start here. Consume the pending
        // restart flags so the UI/state reflects the applied restart.
        if (sampleOffset == lastPatternStartSampleInBlock)
        {
            // Pattern already emitted a Start at this sample earlier in the block.
            // Mark that the bar-restart path observed/consumed the restart so
            // subsequent pattern handling (if it runs later) can skip emitting
            // a duplicate Start. Also clear the pending indicators so UI/state
            // reflect the applied restart.
            lastBarRestartStartSampleInBlock = sampleOffset;
            pendingBarRestart.store(false, std::memory_order_relaxed);
            uiNextRestartPending.store(false, std::memory_order_relaxed);
            // Also clear any deferred pattern-requested restart so it isn't
            // rescheduled to another bar/step.
            pendingPatternRestartTargetBar.store(-1, std::memory_order_relaxed);
        }
        else
        {
            if (sendMidi)
            {
                midi.addEvent(startMsg, sampleOffset);
                extBuffer.addEvent(startMsg, sampleOffset);
            }
            // Record that the bar-restart emitted a Start at this sample so
            // pattern-driven code running later in the block can avoid a duplicate.
            lastBarRestartStartSampleInBlock = sampleOffset;
        }
        // Reflect selected step in UI at restart
        uiStep16.store(juce::jlimit(1, 16, offsetStep), std::memory_order_relaxed);

        if (haveRateChange)
        {
            currentRateIndex = pendingRateIndex;
            pendingRateIndex = -1;
            // changing resolution invalidates prior fractional carries -> reset
            resetAccumulators();
        }
        if (applyShuffleWithBoundary)
        {
            currentShuffleStep = pendingShuffleStep;
            pendingShuffleStep = -1;
            // shuffle applied as part of boundary: clear NEXT indicator if no other pending restart remain
        }
        if (haveStart || haveBarRestart || deferredMatches)
        {
            runActive = true;
            pendingStart = false;
            if (haveBarRestart || deferredMatches)
                pendingBarRestart.store(false, std::memory_order_relaxed);
            
            uiIsRunning.store(true, std::memory_order_relaxed);
            uiPendingStart.store(false, std::memory_order_relaxed);
            uiNextRestartPending.store(false, std::memory_order_relaxed);
            suppressUntilRestart = false; // allow clocks after scheduled restart
        }
        else if (haveRateChange || applyShuffleWithBoundary)
        {
            // Clear NEXT when changes were applied without a separate start request
            uiNextRestartPending.store(false, std::memory_order_relaxed);
        }

        if (legacy && stopOffset >= 0)
        {
            window.gapStart = stopOffset;
            window.gapEnd = sampleOffset;
        }
        else
        {
            window.gapStart = -1;
            window.gapEnd = -1;
        }
        window.startSample = sampleOffset;

        if (runWasActive && haveStart && ! haveBarRestart && ! haveRateChange)
            suppressClockAtBoundaryOnce = true;
        // No extra diagnostics in original behaviour
    }
    return window;
}

//==============================================================================
juce::AudioProcessorEditor* ClockSyncAudioProcessor::createEditor()
{
    return new ClockSyncAudioProcessorEditor(*this);
}

//==============================================================================
void ClockSyncAudioProcessor::getStateInformation(juce::MemoryBlock& destData)
{
    auto state = parameters.copyState();
    // Persist the selected external device id
    if (externalDeviceId.isNotEmpty())
        state.setProperty("externalDeviceId", externalDeviceId, nullptr);
    if (auto xml = state.createXml())
        copyXmlToBinary(*xml, destData);
}

void ClockSyncAudioProcessor::setStateInformation(const void* data, int sizeInBytes)
{
    if (auto xml = getXmlFromBinary(data, sizeInBytes))
    {
        if (xml->hasTagName(parameters.state.getType()))
        {
            auto vt = juce::ValueTree::fromXml(*xml);
            parameters.replaceState(vt);
            // Restore external device id if present
            externalDeviceId = vt.getProperty("externalDeviceId").toString();
            updateDerivedParams();
            updateExternalOut();
        }
    }
}

//==============================================================================
// This creates new instances of the plugin
juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new ClockSyncAudioProcessor();
}
